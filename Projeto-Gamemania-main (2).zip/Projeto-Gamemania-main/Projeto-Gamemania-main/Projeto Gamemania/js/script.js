let currentIndex = 0;
const images = document.querySelectorAll(".carousel img");

function showNextImage() {
images.forEach((img, index) => {
img.classList.remove("active");
if (index === currentIndex) {
img.classList.add("active");
}
});
currentIndex = (currentIndex + 1) % images.length;
}

setInterval(showNextImage, 3000); // Alterna a cada 3 segundos

  $(document).ready(function() {
    $("#cart").hover(
        function() {
            $(this).find("#cart-popup").fadeIn(200);  // Animação suave para mostrar
        },
        function() {
            $(this).find("#cart-popup").fadeOut(200);  // Animação suave para esconder
        }
    );
});

// $(document).ready(function () {
//     $("#loginForm").submit(function (event) {
//         event.preventDefault();
//         var login = document.getElementById('login').value;
//         var senha = document.getElementById('senha').value;

//     if(login == "adm" && senha == "adm"){
//         alert('Login com Sucesso')          
//         location.href = "index2.html"
//     }else{
//         alert('Usuário ou Senha incorreto')
//     };
//     }
// );
// });

    function updateLoginSection() {
        const user = localStorage.getItem("user");
        if (user) {
            const userName = user;
            const userPhoto = "/Gamemania-main/imgs/imagemperfil.png"; // Imagem fictícia do usuário
            $("#loginSection").html(`
                <div class="perfil">
                    <img src="${userPhoto}" class="user-photo" alt="Foto do usuário">
                    <div class="user-name">
                        <span class="greeting">Bem-vindo</span>
                        <span class="username">${userName}</span>
                        <span id="logoutButton">Logoff</span> <!-- Botão de logoff -->
                    </div>
                </div>
            `);
        };
    };

    function cadastrarUsuario(email, senha) {
        const usuario = { email, senha };
        localStorage.setItem('usuario', JSON.stringify(usuario)); // Salva no localStorage
        alert('Usuário cadastrado com sucesso!');
    }
    
    // Função de login
    function logar() {
        const email = document.getElementById("login").value.trim();
        const senha = document.getElementById("senha").value.trim();
    
        const usuario = JSON.parse(localStorage.getItem('usuario')); // Tenta carregar usuário do localStorage
    
        const loginMessage = document.getElementById('loginMessage');
        
        if (!usuario) {
            // Caso não exista usuário registrado
            loginMessage.innerHTML = "Usuário não encontrado. Por favor, cadastre-se.";
            loginMessage.style.color = 'red';
            return;
        }
    
        // Verifica se o e-mail e senha correspondem
        if (email === usuario.email && senha === usuario.senha) {
            loginMessage.innerHTML = "Login bem-sucedido!";
            loginMessage.style.color = 'green';
            
            // Aqui você pode salvar um flag de sessão ou algo como um token
            if (document.getElementById("remember").checked) {
                // Caso a opção "Lembrar de mim" esteja marcada
                localStorage.setItem('remembered', true);
            }
    
            // Exibe o botão de "Atualizar" e "Deletar"
            document.getElementById('update-btn').style.display = 'inline-block';
            document.getElementById('delete-btn').style.display = 'inline-block';
            document.getElementById('loginForm').reset(); // Limpa os campos do formulário

            setTimeout(() => {
                window.location.href = 'index2.html';  // Substitua pelo nome da sua página de destino
            }, 1000);
        } else {
            loginMessage.innerHTML = "Email ou senha incorretos.";
            loginMessage.style.color = 'red';
        }
    }
    
    // Função de verificação simples para "Esqueceu sua senha?"
    function resetarSenha() {
        alert('Função de recuperação de senha em desenvolvimento.');
    }
    
    // Atualizar informações do usuário
    function atualizar() {
        const email = document.getElementById("login").value.trim();
        const senha = document.getElementById("senha").value.trim();
    
        const usuario = JSON.parse(localStorage.getItem('usuario'));
    
        // Verifica se o usuário está autenticado
        if (!usuario) {
            alert("Você precisa estar logado para atualizar seus dados.");
            return;
        }
    
        // Atualiza os dados do usuário no localStorage
        usuario.email = email || usuario.email;
        usuario.senha = senha || usuario.senha;
    
        localStorage.setItem('usuario', JSON.stringify(usuario));
    
        alert("Dados atualizados com sucesso!");
    }
    
    // Deletar a conta do usuário
    function deletar() {
        if (confirm("Tem certeza de que deseja deletar sua conta? Essa ação não pode ser desfeita.")) {
            // Remove o usuário do localStorage
            localStorage.removeItem('usuario');
            localStorage.removeItem('remembered');
            alert("Conta deletada com sucesso!");
            
            // Redefine o formulário e esconde os botões de "Atualizar" e "Deletar"
            document.getElementById('loginForm').reset();
            document.getElementById('update-btn').style.display = 'none';
            document.getElementById('delete-btn').style.display = 'none';
            document.getElementById('loginMessage').innerHTML = "";
        }
    }
    
    // Ao carregar a página, verifique se o usuário está logado
    document.addEventListener("DOMContentLoaded", () => {
        if (localStorage.getItem('remembered')) {
            alert("Bem-vindo de volta!");
            window.location.href = '/dashboard.html'; // Substitua com sua página
        }
    });
    
    // Adicionar evento de submit ao formulário
    document.getElementById("loginForm").addEventListener("submit", function (event) {
        event.preventDefault();
        logar();
    });